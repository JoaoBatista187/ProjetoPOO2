public class Professor extends Usuario{

    private String departamento;

    public void publicarConteudo(){

    }

    public void avaliarProjeto(){

    }

    public void publicarFeedback(){

    }

    public Professor(String nome, String email, String senha) {
        super(nome, email, senha);
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
}