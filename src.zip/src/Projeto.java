import java.util.Date;

public class Projeto extends  Conteudo{

    private Date dataEntrega;
    private String feedbackProf;

    public void enviarProjeto(){

    }

    public Projeto(String titulo, String descricao, Date dataPublicacao) {
        super(titulo, descricao, dataPublicacao);
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getFeedbackProf() {
        return feedbackProf;
    }

    public void setFeedbackProf(String feedbackProf) {
        this.feedbackProf = feedbackProf;
    }
}
