import java.util.ArrayList;

public class Grupo {
    private String nomeGrupo;
    private ArrayList<String> mensagem =  new ArrayList<>();

    public void criarTopico(){

    }

    public String addMensagem(String mensagem){
        this.mensagem.add(mensagem);
        return mensagem;
    }

    public String removeMensagem(String mensagem){
        this.mensagem.remove(mensagem);
        return mensagem;
    }

    public Grupo(String nomeGrupo, ArrayList<String> mensagem) {
        this.nomeGrupo = nomeGrupo;
        this.mensagem = mensagem;
    }

    public String getNomeGrupo() {
        return nomeGrupo;
    }

    public void setNomeGrupo(String nomeGrupo) {
        this.nomeGrupo = nomeGrupo;
    }

    public ArrayList<String> getMensagem() {
        return mensagem;
    }

    public void setMensagem(ArrayList<String> mensagem) {
        this.mensagem = mensagem;
    }
}
