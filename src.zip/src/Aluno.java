import java.util.ArrayList;

public class Aluno extends  Usuario{

    private String matricula;
    private ArrayList<String> historicoDesempenho = new ArrayList();

    public void visualizarConteudo(){

    }

    public void enviarProjeto(){

    }

    public void visualizarFeedback(){

    }

    public Aluno(String nome, String email, String senha) {
        super(nome, email, senha);
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public ArrayList<String> getHistoricoDesempenho() {
        return historicoDesempenho;
    }

    public void setHistoricoDesempenho(ArrayList<String> historicoDesempenho) {
        this.historicoDesempenho = historicoDesempenho;
    }
}
