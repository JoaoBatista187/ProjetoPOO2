public class DesempenhoAluno {
    private Projeto projeto;
    private float nota;

    public double calculaMedia() {
        return calculaMedia();
    }

}
